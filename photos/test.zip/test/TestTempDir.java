package test;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class TestTempDir {
	@TempDir
	File TempDir;
	
	@Test
	void test_file_created() throws IOException{
		assertTrue(this.TempDir.exists());
		
		File file = new File(this.TempDir, "students.txt");
		List<String> students = Arrays.asList("First", "Second", "Third");
		try(PrintWriter pw = new PrintWriter(file)) {
			for (String student: students) {
				pw.println(student);
			}
		}
		
		assertAll(
				()-> assertTrue(Files.exists(file.toPath())),
				()-> {
					List<String> checkLines = Files.readAllLines(file.toPath());
					assertLinesMatch(students, checkLines);
				}
			);
	}
}
