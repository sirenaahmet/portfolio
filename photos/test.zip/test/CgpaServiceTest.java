package test;

import main.connection.ConnectionManager;
import main.migrations.Migration;
import main.model.Enrollment;
import main.model.Student;
import main.repository.EnrollmentRepository;
import main.repository.StudentRepository;
import main.services.CgpaService;
import org.junit.jupiter.api.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CgpaServiceTest {

    static ConnectionManager connectionManager;
    static CgpaService cgpaService;
    static StudentRepository studentRepository;
    static EnrollmentRepository enrollmentRepository;

    /// data used on each test
    List<Student> students = new ArrayList<>();
    List<Enrollment> enrollments = new ArrayList<>();

    @BeforeAll
    public static void globalSetup() throws SQLException {
        connectionManager = ConnectionManager.connect("jdbc:sqlite:students_test.db");
        studentRepository = new StudentRepository(connectionManager.getConnection());
        enrollmentRepository = new EnrollmentRepository(connectionManager.getConnection());
        cgpaService = new CgpaService(studentRepository, enrollmentRepository);
        Migration.run(connectionManager.getConnection());
    }

    @AfterAll
    public static void globalTeardown() throws SQLException {
        connectionManager.close();
        connectionManager.drop();
    }

    @BeforeEach
    public void init() throws SQLException {
    	students.add(new Student(1, "Std 1", 1, 0f));
    	students.add(new Student(2, "Std 2", 2, 0f));
    	students.add(new Student(3, "Std 3", 2, 0f));
    	studentRepository.save(students);
    	
    	enrollments.add(new Enrollment(1, 1, "CEN 101", 2022, "Fall", 2.5f));
    	enrollments.add(new Enrollment(2, 1, "CEN 102", 2022, "Fall", 2.7f));
    	enrollments.add(new Enrollment(3, 1, "CEN 103", 2022, "Fall", 2.5f));
    	enrollments.add(new Enrollment(4, 2, "CEN 101", 2022, "Fall", 2.5f));
    	enrollments.add(new Enrollment(5, 2, "CEN 102", 2022, "Fall", 2.5f));
    	enrollmentRepository.save(enrollments);
    }

    @AfterEach
    public void teardown() throws SQLException {
    	studentRepository.remove(students);
    	enrollmentRepository.remove(enrollments);
    }

    @Test
    public void testUpdatesStudentWithGradesCGPA() throws SQLException {
    	Student std = students.get(0);
    	cgpaService.updateCgpa(std);
    	
    	Student updateFromDB = studentRepository.find(std.getId());
    	Assertions.assertEquals(updateFromDB.getCgpa(), std.getCgpa());
    }

    @Test
    public void testUpdatesStudentWithoutGradesCGPA() throws SQLException {
    	Student std = students.get(2);
    	cgpaService.updateCgpa(std);
    	
    	Student updatedStdFromDB = studentRepository.find(std.getId());
    	Assertions.assertEquals(
    			updatedStdFromDB.getCgpa(),
    			std.getCgpa();
    			);
    }
}
